﻿'Dmitry Khutornoy
'Jeeprody
'Version3
'april 13 2022
Imports System.IO
Public Class Form1
    'assign variables
    Public TP As Integer = 0
    Public question As Integer = 0
    Public highscore As String = My.Computer.FileSystem.ReadAllText("Highscore.txt")
    Public Shared Custom Event FormClosing As System.ComponentModel.CancelEventHandler
        AddHandler(value As System.ComponentModel.CancelEventHandler)

        End AddHandler
        RemoveHandler(value As System.ComponentModel.CancelEventHandler)

        End RemoveHandler
        RaiseEvent(sender As Object, e As System.ComponentModel.CancelEventArgs)

        End RaiseEvent
    End Event

    ''Repeat for each button  vvvvvvvvvvv
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        'load the question
        Form2.Question.Text = "What property controls the text of an object?"
        Form2.A1.Text = "Text"
        Form2.A2.Text = "Name"
        Form2.A3.Text = "Color"
        Form2.A4.Text = "Visible"
        'see if the right answer was picked
        question = 1


    End Sub
    ''Repeat for each button ^^^^^^^^^

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What do computers think in?"
        Form2.A1.Text = "Letters"
        Form2.A2.Text = "Numbers"
        Form2.A3.Text = "Binary"
        Form2.A4.Text = "Colors"
        question = 2


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What is the default name of a Form?"
        Form2.A1.Text = "Form1"
        Form2.A2.Text = "1.Form"
        Form2.A3.Text = "First Form"
        Form2.A4.Text = "Form"
        question = 3

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "Vb is consdered a:  "
        Form2.A1.Text = "Low-level language"
        Form2.A2.Text = "High-level language"
        Form2.A3.Text = "Binary"
        Form2.A4.Text = "Medium-level language"
        question = 4


    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What does CPU stand for?"
        Form2.A1.Text = "Computer power units"
        Form2.A3.Text = "Centeral Processing Unit"
        Form2.A2.Text = "Commercial potential understanding"
        Form2.A4.Text = "Centimeters per unit"
        question = 5
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What does RAM stand for?"
        Form2.A1.Text = "Random access money"
        Form2.A2.Text = "Right after me"
        Form2.A3.Text = "Read Only Memory"
        Form2.A4.Text = "Random Access Memory"
        question = 6
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What does ROM stand for?"
        Form2.A1.Text = "Random access money"
        Form2.A2.Text = "Right after me"
        Form2.A3.Text = "Read Only Memory"
        Form2.A4.Text = "Random Access Memory"
        question = 7


    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What does PC stand for?"
        Form2.A1.Text = "Personal Computer"
        Form2.A2.Text = "Pretense Case"
        Form2.A3.Text = "Printer Cartridge"
        Form2.A4.Text = "Plastic Case"
        question = 8
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "When was the first computer invented"
        Form2.A1.Text = "1980"
        Form2.A2.Text = "2022"
        Form2.A3.Text = "1922"
        Form2.A4.Text = "1822"
        question = 9

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "Who made the first computer"
        Form2.A1.Text = "Jeff Bazos"
        Form2.A2.Text = "Alan Turing"
        Form2.A3.Text = "Bill Gates"
        Form2.A4.Text = "D.E.L.T.A Corp."
        question = 10
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What company did Steve Jobs first work for?"
        Form2.A1.Text = "Nintendo"
        Form2.A2.Text = "Apple"
        Form2.A3.Text = "IBM"
        Form2.A4.Text = "Atari"
        question = 11
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Label2.Refresh()
        Me.Visible = False
        Form2.Visible = True
        Form2.Question.Text = "What was the first form of computer storage?"
        Form2.A1.Text = "SSD"
        Form2.A2.Text = "HDD"
        Form2.A3.Text = "Floppy disks"
        Form2.A4.Text = "Punch Cards"
        question = 12
    End Sub

    Public Sub answer1()
        If question = 1 Then
            'add the points
            TP += 100
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 3 Then
            'add points
            TP += 300
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 8 Then
            'add points
            TP += 400
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False

        End If

    End Sub
    Public Sub answer2()
        If question = 5 Then
            'add the points
            TP += 100
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 10 Then
            'add the points
            TP += 200
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 4 Then
            'add the points
            TP += 500
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If

    End Sub
    Public readscore As Integer

    'do this if the form is closing
    Public Sub Form1_closing(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Using rFile As StreamReader = New StreamReader("Highscore.txt")
            'Read the score
            readscore = Convert.ToInt32(rFile.ReadLine)
        End Using
        Using writeFile As StreamWriter = New StreamWriter("Highscore.txt")
            'show the score
            MessageBox.Show("Score:   " + Convert.ToString(TP))
            If (TP > readscore) Then
                MessageBox.Show("High Score is:  " + Convert.ToString(TP))
                'Show the high score and write to the file
                writeFile.WriteLine(TP)
            Else
                MessageBox.Show("You did not get a new high score :(")
            End If

        End Using

    End Sub
    Public Sub answer3()
        If question = 2 Then
            'add the points
            TP += 200
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 7 Then
            'add the points
            TP += 300
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If

    End Sub
    Public Sub answer4()
        If question = 6 Then
            'add the points
            TP += 200
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 9 Then
            'add the points
            TP += 100
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 11 Then
            'add the points
            TP += 300
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If
        If question = 12 Then
            'add the points
            TP += 500
            Label2.Text = "Total Points: " + Str(TP)
            'refresh the points
            Label2.Refresh()
            'get out of the if statment
            Form2.A1hasbeenclicked = False
        End If

    End Sub



End Class
