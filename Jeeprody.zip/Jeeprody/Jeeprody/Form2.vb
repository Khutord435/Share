﻿Public Class Form2
    Public A1hasbeenclicked As Boolean
    Public A2hasbeenclicked As Boolean
    Public A3hasbeenclicked As Boolean
    Public A4hasbeenclicked As Boolean

    Private Sub A1_Click(sender As Object, e As EventArgs) Handles A1.Click
        A1hasbeenclicked = True
        Form1.Label2.Refresh()
        Me.Visible = False
        Form1.Visible = True
        Form1.Label2.Refresh()
        Form1.answer1()
    End Sub

    Private Sub A2_Click(sender As Object, e As EventArgs) Handles A2.Click
        A2hasbeenclicked = True
        Form1.Label2.Refresh()
        Me.Visible = False
        Form1.Visible = True
        Form1.Label2.Refresh()
        Form1.answer2()
    End Sub

    Private Sub A3_Click(sender As Object, e As EventArgs) Handles A3.Click
        A3hasbeenclicked = True
        Form1.Label2.Refresh()
        Me.Visible = False
        Form1.Visible = True
        Form1.Label2.Refresh()
        Form1.answer3()
    End Sub

    Private Sub A4_Click(sender As Object, e As EventArgs) Handles A4.Click
        A4hasbeenclicked = True
        Form1.Label2.Refresh()
        Me.Visible = False
        Form1.Visible = True
        Form1.Label2.Refresh()
        Form1.answer4()
    End Sub
End Class